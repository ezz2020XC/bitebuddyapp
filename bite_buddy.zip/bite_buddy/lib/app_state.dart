import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _swip = prefs.getStringList('ff_swip')?.map(int.parse).toList() ?? _swip;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _userDiet = '';
  String get userDiet => _userDiet;
  set userDiet(String value) {
    _userDiet = value;
  }

  List<String> _userAllergens = [];
  List<String> get userAllergens => _userAllergens;
  set userAllergens(List<String> value) {
    _userAllergens = value;
  }

  void addToUserAllergens(String value) {
    userAllergens.add(value);
  }

  void removeFromUserAllergens(String value) {
    userAllergens.remove(value);
  }

  void removeAtIndexFromUserAllergens(int index) {
    userAllergens.removeAt(index);
  }

  void updateUserAllergensAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    userAllergens[index] = updateFn(_userAllergens[index]);
  }

  void insertAtIndexInUserAllergens(int index, String value) {
    userAllergens.insert(index, value);
  }

  List<String> _userIngredientDislikes = [];
  List<String> get userIngredientDislikes => _userIngredientDislikes;
  set userIngredientDislikes(List<String> value) {
    _userIngredientDislikes = value;
  }

  void addToUserIngredientDislikes(String value) {
    userIngredientDislikes.add(value);
  }

  void removeFromUserIngredientDislikes(String value) {
    userIngredientDislikes.remove(value);
  }

  void removeAtIndexFromUserIngredientDislikes(int index) {
    userIngredientDislikes.removeAt(index);
  }

  void updateUserIngredientDislikesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    userIngredientDislikes[index] = updateFn(_userIngredientDislikes[index]);
  }

  void insertAtIndexInUserIngredientDislikes(int index, String value) {
    userIngredientDislikes.insert(index, value);
  }

  bool _timerrunning = false;
  bool get timerrunning => _timerrunning;
  set timerrunning(bool value) {
    _timerrunning = value;
  }

  List<int> _swip = [];
  List<int> get swip => _swip;
  set swip(List<int> value) {
    _swip = value;
    prefs.setStringList('ff_swip', value.map((x) => x.toString()).toList());
  }

  void addToSwip(int value) {
    swip.add(value);
    prefs.setStringList('ff_swip', _swip.map((x) => x.toString()).toList());
  }

  void removeFromSwip(int value) {
    swip.remove(value);
    prefs.setStringList('ff_swip', _swip.map((x) => x.toString()).toList());
  }

  void removeAtIndexFromSwip(int index) {
    swip.removeAt(index);
    prefs.setStringList('ff_swip', _swip.map((x) => x.toString()).toList());
  }

  void updateSwipAtIndex(
    int index,
    int Function(int) updateFn,
  ) {
    swip[index] = updateFn(_swip[index]);
    prefs.setStringList('ff_swip', _swip.map((x) => x.toString()).toList());
  }

  void insertAtIndexInSwip(int index, int value) {
    swip.insert(index, value);
    prefs.setStringList('ff_swip', _swip.map((x) => x.toString()).toList());
  }

  List<String> _recent = [];
  List<String> get recent => _recent;
  set recent(List<String> value) {
    _recent = value;
  }

  void addToRecent(String value) {
    recent.add(value);
  }

  void removeFromRecent(String value) {
    recent.remove(value);
  }

  void removeAtIndexFromRecent(int index) {
    recent.removeAt(index);
  }

  void updateRecentAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    recent[index] = updateFn(_recent[index]);
  }

  void insertAtIndexInRecent(int index, String value) {
    recent.insert(index, value);
  }

  bool _searchavtive = false;
  bool get searchavtive => _searchavtive;
  set searchavtive(bool value) {
    _searchavtive = value;
  }

  bool _searchactive2 = false;
  bool get searchactive2 => _searchactive2;
  set searchactive2(bool value) {
    _searchactive2 = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
