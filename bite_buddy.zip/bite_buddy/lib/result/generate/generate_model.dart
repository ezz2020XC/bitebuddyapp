import '/flutter_flow/flutter_flow_util.dart';
import 'generate_widget.dart' show GenerateWidget;
import 'package:flutter/material.dart';

class GenerateModel extends FlutterFlowModel<GenerateWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  bool isDataUploading = false;
  List<FFUploadedFile> uploadedLocalFiles = [];
  List<String> uploadedFileUrls = [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
