import '/flutter_flow/flutter_flow_util.dart';
import 'preference_item_widget.dart' show PreferenceItemWidget;
import 'package:flutter/material.dart';

class PreferenceItemModel extends FlutterFlowModel<PreferenceItemWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
