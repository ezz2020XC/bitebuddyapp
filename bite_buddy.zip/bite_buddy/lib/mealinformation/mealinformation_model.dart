import '/flutter_flow/flutter_flow_util.dart';
import 'mealinformation_widget.dart' show MealinformationWidget;
import 'package:flutter/material.dart';

class MealinformationModel extends FlutterFlowModel<MealinformationWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
