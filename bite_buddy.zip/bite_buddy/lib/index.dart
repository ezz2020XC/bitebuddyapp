// Export pages
export '/pages/meals/splash/splash_widget.dart' show SplashWidget;
export '/pages/onboarding/sign_in/sign_in_widget.dart' show SignInWidget;
export '/pages/onboarding/onboarding_slideshow/onboarding_slideshow_widget.dart'
    show OnboardingSlideshowWidget;
export '/pages/onboarding/onboarding_create_account/onboarding_create_account_widget.dart'
    show OnboardingCreateAccountWidget;
export '/pages/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/pages/meals/meal_details/meal_details_widget.dart'
    show MealDetailsWidget;
export '/pages/profile/profile/profile_widget.dart' show ProfileWidget;
export '/pages/profile/edit_profile/edit_profile_widget.dart'
    show EditProfileWidget;
export '/pages/profile/about_us/about_us_widget.dart' show AboutUsWidget;
export '/pages/profile/support_center/support_center_widget.dart'
    show SupportCenterWidget;
export '/pages/onboarding/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/result/generate/generate_widget.dart' show GenerateWidget;
export '/result/imgresult/imgresult_widget.dart' show ImgresultWidget;
export '/result/generatetext/generatetext_widget.dart' show GeneratetextWidget;
export '/result/textresult/textresult_widget.dart' show TextresultWidget;
export '/result/imgresult_copy/imgresult_copy_widget.dart'
    show ImgresultCopyWidget;
export '/result/imgresult_copy_copy/imgresult_copy_copy_widget.dart'
    show ImgresultCopyCopyWidget;
export '/mealinformation/mealinformation_widget.dart'
    show MealinformationWidget;
export '/mealinformation_copy/mealinformation_copy_widget.dart'
    show MealinformationCopyWidget;
export '/mealinformation_copy_copy/mealinformation_copy_copy_widget.dart'
    show MealinformationCopyCopyWidget;
export '/result/textresult_copy/textresult_copy_widget.dart'
    show TextresultCopyWidget;
export '/mealinformation_copy_copy2/mealinformation_copy_copy2_widget.dart'
    show MealinformationCopyCopy2Widget;
export '/fav/fav_widget.dart' show FavWidget;
export '/search/search_widget.dart' show SearchWidget;
