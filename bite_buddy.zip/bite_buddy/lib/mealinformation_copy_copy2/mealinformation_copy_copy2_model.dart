import '/flutter_flow/flutter_flow_util.dart';
import 'mealinformation_copy_copy2_widget.dart'
    show MealinformationCopyCopy2Widget;
import 'package:flutter/material.dart';

class MealinformationCopyCopy2Model
    extends FlutterFlowModel<MealinformationCopyCopy2Widget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
  }
}
