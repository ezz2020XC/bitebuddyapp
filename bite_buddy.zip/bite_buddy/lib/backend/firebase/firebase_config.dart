import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyC0InxGaL5W121uA4YHLuBFcBgG8FF6e5Q",
            authDomain: "bite-buddy-test.firebaseapp.com",
            projectId: "bite-buddy-test",
            storageBucket: "bite-buddy-test.appspot.com",
            messagingSenderId: "341567551534",
            appId: "1:341567551534:web:368675ff18f448522847bf"));
  } else {
    await Firebase.initializeApp();
  }
}
