import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FavRecord extends FirestoreRecord {
  FavRecord._(
    super.reference,
    super.data,
  ) {
    _initializeFields();
  }

  // "meal" field.
  List<DocumentReference>? _meal;
  List<DocumentReference> get meal => _meal ?? const [];
  bool hasMeal() => _meal != null;

  void _initializeFields() {
    _meal = getDataList(snapshotData['meal']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('fav');

  static Stream<FavRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FavRecord.fromSnapshot(s));

  static Future<FavRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FavRecord.fromSnapshot(s));

  static FavRecord fromSnapshot(DocumentSnapshot snapshot) => FavRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FavRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FavRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FavRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FavRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFavRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class FavRecordDocumentEquality implements Equality<FavRecord> {
  const FavRecordDocumentEquality();

  @override
  bool equals(FavRecord? e1, FavRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.meal, e2?.meal);
  }

  @override
  int hash(FavRecord? e) => const ListEquality().hash([e?.meal]);

  @override
  bool isValidKey(Object? o) => o is FavRecord;
}
